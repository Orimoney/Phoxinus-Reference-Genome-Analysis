# Phoxinus Reference Genome



## Phoxinus Reference genome analysis scripts
This directory contains scripts used in the analysis of the Phoxinus phoxinus assembly and annotation manuscript, with descriptions of parameters and tools used for each analysis.
